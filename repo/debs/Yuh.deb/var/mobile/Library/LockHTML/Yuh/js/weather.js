conditions = {
  "Tornado": "icons/tornado.svg",
  "Tropical Storm": "icons/tropical-storm.svg",
  "Hurricane": "icons/hurricane.svg",
  "Thunderstorm": "icons/thunderstorm.svg",
  "Snow": "icons/snow.svg",
  "Sleet": "icons/sleet.svg",
  "Freezing Drizzle": "icons/freezing-drizzle.svg",
  "Drizzle": "icons/drizzle.svg",
  "Freezing Rain": "icons/freezing-drizzle.svg",
  "Showers": "icons/drizzle.svg",
  "Flurries": "icons/flurries.svg", 
  "Hail": "icons/hail.svg",
  "Dust": "icons/dust.svg",
  "Fog": "icons/fog.svg",
  "Haze": "icons/haze.svg",
  "Smoky": "icons/smoky.svg", 
  "Blustery": "icons/blustery.svg",
  "Windy": "icons/windy.svg",
  "Cold": "icons/cold.svg",
  "Cloudy": "icons/cloudy.svg",
  "Clear": "icons/sunny.svg",
  "Sunny": "icons/sunny.svg",
  "Fair": "icons/fair.svg",
  "Hot": "icons/thunderstorm.svg",
  "Thunderstorms": "icons/thunderstorm.svg",
  "Heavy Snow": "icons/snow.svg",
  "Light Snow": "icons/snow.svg",
  "Partly Cloudy": "icons/partly-cloudy.svg",
  "blank": "icons/blank.svg"
}

function updateWeather() {
  var condition = document.getElementById("condition-icon");
  // set clear to be moon when it is night instead of the sun
  var hour = new Date().getHours();
  if (weather.condition == "Clear" && (hour < 5 || hour >= 20)) {
    condition.src = "icons/clear-night.svg";
  } else {
    condition.src = conditions[weather.condition];
  }

  if (SimpleWeather) {
    document.getElementById("city").innerHTML = "";
    document.getElementById("rain-chance").innerHTML = "";
  } else {
    document.getElementById("city").innerHTML = weather.city;
    document.getElementById("rain-chance").innerHTML = weather.chanceofrain + "% chance of rain";
  }

  document.getElementById("temperature").innerHTML = weather.temperature + "&deg;";
  document.getElementById("temp-lowhigh").innerHTML = weather.low + "&deg;/" + weather.high + "&deg;";

}
