function updateReminders() {
  document.getElementById("num-reminders").innerHTML = reminders.length;
}