// set to true to set the clock to 24 hour mode
var TwentyFourHour = false;
// set to true to hide city name and percent chance of rain
var SimpleWeather = true;
var HideReminders = false;