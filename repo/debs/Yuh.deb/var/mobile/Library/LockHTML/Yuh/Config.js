var TwentyFourHour = false; // Sets the clock to 24 hr mode
var HideAMPM = true; // Hides am/pm from the clock
var SimpleWeather = true; // Hides city name and percent chance of rain
var DisableWeather = false; // Hides weather
var HideReminders = true; // Hides the reminders count and icon
var BackgroundColor = "rgba(18, 18, 18, 0.5)"; // Sets the background color of the widget
var BottomBorderColor = "#191919"; // Sets the color of the bottom border