function updateInfo() {
  document.getElementById("artwork-img").src = "/var/mobile/Documents/Artwork.jpg?" + new Date().getTime();
  document.getElementById("container").style.display = "flex";
  document.getElementById("title").innerHTML = title;
  document.getElementById("artist").innerHTML = artist;
  document.getElementById("album").innerHTML = album;
}

function mainUpdate(type) {
  if (type == "music") {
    var playbackButton = document.getElementById("playback");
    if (isplaying) {
      updateInfo();
      playbackButton.src="icons/pause.svg";
    } else {
      playbackButton.src="icons/play.svg"
    }
  }
}
