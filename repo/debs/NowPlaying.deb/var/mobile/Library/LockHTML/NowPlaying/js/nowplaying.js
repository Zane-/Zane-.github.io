function updateInfo() {
  document.getElementById("artwork-img").src = "/var/mobile/Documents/Artwork.jpg?" + new Date().getTime();
  document.getElementById("container").style.display = "flex";
  document.getElementById("title").innerHTML = title;
  document.getElementById("artist").innerHTML = artist;
  document.getElementById("album").innerHTML = album;
}

