var Spotify = false; // Sets whether the app logo is spotify or music
var BackgroundColor = "rgba(18, 18, 18, 0.5)"; // Sets the background color for the widget
var BottomBorderColor = "#191919"; // Sets the color of the bottom border
var BorderRadius = "5px"; // Sets the border radius of the widget
var BoxShadowOpacity = "0.25"; // Sets the opacity of the shadow of the widget