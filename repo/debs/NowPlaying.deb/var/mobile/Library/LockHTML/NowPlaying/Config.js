// Replace the music icon with the Spotify logo
var Spotify = false;