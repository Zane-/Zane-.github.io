function updateBattery() {
  var battery = document.getElementById("batteryForeground");
  // update height/width
  if (Vertical) {
    battery.style.height = batteryPercent + "%";
  } else {
    battery.style.width = batteryPercent + "%";
  }
  // update color
  if (batteryPercent >= 65 || batteryCharging) {
    if (HighGradientStart != "" && HighGradientStop != "") {
      if (Vertical) {
        battery.style.backgroundImage = "-webkit-linear-gradient(" + HighGradientStart + ", " + HighGradientStop + ")";
      } else {
        battery.style.backgroundImage = "-webkit-linear-gradient(right, " + HighGradientStart + ", " + HighGradientStop + ")";
      }
    } else {
      battery.style.backgroundColor = HighSolid;
    }
  } else if (batteryPercent < 20) {
    if (LowGradientStart != "" && LowGradientStop != "") {
      if (Vertical) {
        battery.style.backgroundImage = "-webkit-linear-gradient(" + LowGradientStart + ", " + LowGradientStop + ")";
      } else {
        battery.style.backgroundImage = "-webkit-linear-gradient(right, " + LowGradientStart + ", " + LowGradientStop + ")";
      }
    } else {
      battery.style.backgroundColor = LowSolid;
    } 
  } else if (batteryPercent < 65) {
    if (MedGradientStart != "" && MedGradientStop != "") {
      if (Vertical) {
        battery.style.backgroundImage = "-webkit-linear-gradient(" + MedGradientStart + ", " + MedGradientStop + ")";
      } else {
        battery.style.backgroundImage = "-webkit-linear-gradient(right, " + MedGradientStart + ", " + MedGradientStop + ")";
      }
    } else {
      battery.style.backgroundColor = MedSolid;
    }
  }
}

function mainUpdate(type) {
  if (type == "battery") {
    updateBattery();
  }
}