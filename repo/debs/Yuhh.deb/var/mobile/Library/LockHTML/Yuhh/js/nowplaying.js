function updateInfo() {
  if (title == "(null)" && artist == "(null)" && album == "(null)") {
    document.getElementById("artwork-img").src = "images/default.png";
  } else {
    document.getElementById("artwork-img").src = "/var/mobile/Documents/Artwork.jpg?" + new Date().getTime();
  }
  
  if (title == "(null)") {
    document.getElementById("title").innerHTML = "";
  } else {
    document.getElementById("title").innerHTML = title;
  }
  if (artist == "(null)") {
    document.getElementById("artist").innerHTML = "";
  } else {
    document.getElementById("artist").innerHTML = artist;
  }
  if (album == "(null)") {
    document.getElementById("album").innerHTML = "";
  } else {
    document.getElementById("album").innerHTML = album;
  }
}
