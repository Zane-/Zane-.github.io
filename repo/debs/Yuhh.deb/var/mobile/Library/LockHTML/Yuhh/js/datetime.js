var weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];

function updateDateTime() { 
	var dateTime = new Date();
	var hours = dateTime.getHours();
	var minutes = dateTime.getMinutes() < 10 ? '0' + dateTime.getMinutes() : dateTime.getMinutes();
	var period = (hours < 12) ? "am" : "pm";
	var weekday = dateTime.getDay();
	var month = dateTime.getMonth();
	var dayOfMonth = dateTime.getDate() < 10 ? '0' + dateTime.getDate() : dateTime.getDate();

	if (TwentyFourHour) {
		hours = (hours < 10 ? "0" : "") + hours;
	} else {
		hours = (hours > 12) ? hours - 12 : hours;
		hours = (hours == 0) ? 12 : hours;
	}
	
	var timeString = `${hours}:${minutes}`;
	if (!HideAMPM && !TwentyFourHour) {
		timeString = timeString + period;
	} 

	document.getElementById("time").innerHTML = timeString;

	var dateString = `${weekdays[weekday]}, ${months[month]} ${dayOfMonth}`
	document.getElementById("date").innerHTML = dateString;
}

function init() {
	updateDateTime();
	setInterval(updateDateTime, 1000);
}