conditions = {
  "blank": {
    day: "icons/weather/neutral/blank.svg",
    night: "icons/weather/neutral/blank.svg"
  },
  "Hot": {
    day: "icons/weather/day/wi-day-sunny.svg",
    night: "icons/weather/night/wi-night-clear.svg"
  },
  "Cold": {
    day: "icons/weather/neutral/wi-snowflake-cold.svg",
    night: "icons/weather/neutral/wi-snowflake-cold.svg"
  },
  "Blustery": {
    day: "icons/weather/neutral/wi-strong-wind.svg",
    night: "icons/weather/neutral/wi-strong-wind.svg"
  },
  "Windy": {
    day: "icons/weather/neutral/wi-windy.svg",
    night: "icons/weather/neutral/wi-windy.svg"
  },
  "Tornado": {
    day: "icons/weather/neutral/tornado.svg",
    night: "icons/weather/neutral/tornado.svg",
  },
  "Smoky": {
    day: "icons/weather/neutral/wi-smoke.svg", 
    night: "icons/weather/neutral/wi-smoke.svg"
  },
  "Hurricane": {
    day: "icons/weather/neutral/wi-hurricane.svg",
    night: "icons/weather/neutral/wi-hurricane.svg"
  },
  "Dust": {
    day: "icons/weather/neutral/wi-dust.svg",
    night: "icons/weather/neutral/wi-dust.svg"
  },
  "Fog": {
    day: "icons/weather/day/wi-day-fog.svg",
    night: "icons/weather/night/wi-night-fog.svg"
  },
  "Haze": {
    day: "icons/weather/day/wi-day-haze.svg",
    night: "icons/weather/night/wi-night-fog.svg"
  },
  "Tropical Storm": {
    day: "icons/weather/day/wi-day-thunderstorm.svg",
    night: "icons/weather/night/wi-night-alt-thunderstorm.svg"
  },
  "Thunderstorms": {
    day: "icons/weather/day/wi-day-thunderstorm.svg",
    night: "icons/weather/night/wi-night-alt-thunderstorm.svg"
  },
  "Thunderstorm": {
    day: "icons/weather/day/wi-day-thunderstorm.svg",
    night: "icons/weather/night/wi-night-alt-thunderstorm.svg"
  },
  "Sleet": {
    day: "icons/weather/day/wi-day-sleet.svg",
    night: "icons/weather/night/wi-night-alt-sleet.svg"
  },
  "Freezing Drizzle": {
    day: "icons/weather/day/wi-day-rain-mix.svg",
    night: "icons/weather/night/wi-night-alt-rain-mix.svg"
  },
  "Drizzle": {
    day: "icons/weather/day/wi-day-showers.svg",
    night: "icons/weather/night/wi-night-alt-showers.svg"
  },
  "Freezing Rain": {
    day: "icons/weather/day/wi-day-rain-mix.svg",
    night: "icons/weather/night/wi-night-alt-rain-mix.svg"
  },
  "Showers": {
    day: "icons/weather/day/wi-day-showers.svg",
    night: "icons/weather/night/wi-night-alt-showers.svg"
  },
  "Flurries": {
    day: "icons/weather/day/wi-day-snow-wind.svg", 
    night: "icons/weather/night/wi-night-alt-snow-wind.svg"
  },
  "Hail": {
    day: "icons/weather/day/wi-day-hail.svg",
    night: "icons/weather/night/wi-night-alt-hail.svg",
  },
  "Heavy Snow": {
    day: "icons/weather/day/wi-day-snow.svg",
    night: "icons/weather/night/wi-night-alt-snow.svg"
  },
  "Light Snow": {
    day: "icons/weather/day/wi-day-snow.svg",
    night: "icons/weather/night/wi-night-alt-snow.svg"
  },
  "Snow": {
    day: "icons/weather/day/wi-day-snow.svg",
    night: "icons/weather/night/wi-night-alt-snow.svg"
  },
  "Partly Cloudy": {
    day: "icons/weather/day/wi-day-sunny-overcast.svg",
    night: "icons/weather/night/wi-night-alt-partly-cloudy.svg"
  },
  "Mostly Cloudy": {
    day: "icons/weather/day/wi-day-cloudy.svg",
    night: "icons/weather/night/wi-night-alt-cloudy.svg"
  },
  "Cloudy": {
    day: "icons/weather/day/wi-day-cloudy-high.svg",
    night: "icons/weather/night/wi-night-alt-cloudy-high.svg"
  },
  "Clear": {
    day: "icons/weather/day/wi-day-sunny.svg",
    night: "icons/weather/night/wi-night-clear.svg"
  },
  "Mostly Clear": {
    day: "icons/weather/day/wi-day-sunny.svg",
    night: "icons/weather/night/wi-night-clear.svg"
  },
  "Mostly Sunny": {
    day: "icons/weather/day/wi-day-sunny.svg",
    night: "icons/weather/night/wi-night-clear.svg"
  },
  "Sunny": {
    day: "icons/weather/day/wi-day-sunny.svg",
    night: "icons/weather/night/wi-night-clear.svg"
  },
  "Fair": {
    day: "icons/weather/day/wi-day-sunny.svg",
    night: "icons/weather/night/wi-night-clear.svg"
  }
}

function updateWeather() {
  var condition = document.getElementById("condition-icon");
  var hour = new Date().getHours();
  if (!weather.condition in conditions) {
    condition.src = conditions["blank"]["day"];
  } else {
    if ((hour < 5 || hour >= 20)) {
      condition.src = conditions[weather.condition]["night"];
    } else {
      condition.src = conditions[weather.condition]["day"];
    }
  }

  if (!SimpleWeather) {
    document.getElementById("city").innerHTML = weather.city;
    document.getElementById("rain-chance").innerHTML = weather.chanceofrain + "% chance of rain";
  }

  document.getElementById("temperature").innerHTML = weather.temperature + "&deg;";
  document.getElementById("temp-lowhigh").innerHTML = weather.low + "&deg;/" + weather.high + "&deg;";
}